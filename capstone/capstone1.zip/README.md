Following are the details of Software environments with version details :
```
• Python 3.6.0
• Tensorflow 1.1.0
• Keras 2.1.6
```
Google Colab was used for this project.
https://colab.research.google.com/

The link to the Kaggle competition is:
https://www.kaggle.com/c/planet-understanding-the-amazon-from-space/

Following are the files included in the submission :
```
• proposal.pdf
• report.pdf
• MyCapstone_1_3 (3).ipynb
```